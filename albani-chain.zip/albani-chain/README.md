# Albani Chain

Proyek blockchain pertama dengan Flask dan PostgreSQL.